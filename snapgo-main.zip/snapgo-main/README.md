# snapgo
sc simple tapi berkelas

author @Sptty Chan
# login
cookies
# cara pemasangan
$ pkg upgrade && pkg update

$ pkg install python

$ pkg install rich

$ pkg install play-audio

$ pip install requests

$ pip install bs4

$ pip install mechanize

$ pip install futures
# cara menjalankan
$ cd snapgo

$ python snapgo.py
